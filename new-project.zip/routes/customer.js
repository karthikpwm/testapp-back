const router = require('express').Router()

const { catchErrors } = require('./../handlers/errorHandler')
const customerContoller = require('../controllers/customerController')

router.post("/insert", catchErrors(customerContoller.addRecord))

module.exports = router
