const customer = require('./../models/Customer')


exports.addRecord = async (req, res) => {
    if(req.body.constructor === Object && Object.keys(req.body).length === 0){
      throw '400:Parameter not Valid'
    }
    console.log('asdfasdf')
    const result = await customer.insert( req.body )

    console.log(result)
    res.json({
      message: `Customer register successfully`
    })
};

exports.updateRecord = async (req,res) => {
  if(req.body.constructor === Object && Object.keys(req.body).length === 0){
    throw '400:Parameter not Valid'
  }

  const result = await customer.insert( req.body )

  console.log(result)
  res.json({
    message: `Customer register successfully`
  })
}