const {db} = require('./../config/config')

const insertOrUpdate = async (param) => {
  const con = await db.getConnection()

  try {
    await con.beginTransaction();
    let sql;
    const bill = param.bill
    let billID;

    if(bill.billID === undefined || parseInt(bill.billID) == 0 ){
      sql = "INSERT INTO customer_bill (bill_no, date, net_amount, discount, total, remarks, customer_id, balance) VALUE (?, ?, ?, ?, ?, ?, ?, ?)";      
      const billResult = await con.query(sql,[
        bill.billNo, bill.date, bill.netAmount, bill.discount, bill.total, bill.remarks, bill.customerID, 0
      ])
      billID = billResult[0].insertId
    } else {
      sql = "UPDATE customer_bill SET bill_no = ?, date = ?, net_amount = ?, discount = ?, total = ?, remarks = ?, balance = ? WHERE bill_id = ?";
      await con.query(sql,[
        bill.billNo, bill.date, bill.netAmount, bill.discount, bill.total, bill.remarks, bill.balance, bill.billID
      ])
      billID = bill.billID
    }

    await param.order.forEach(async element => {
      if(element.orderID === undefined || parseInt(element.orderID) == 0){
        sql = `INSERT INTO customer_order ( customer_id, paper_id, bill_id, amount, date, created_at) VALUES ( ?, ?, ?, ?, ?, ?) `
        await con.query(sql, [
          element.customerID,
          element.paperID,
          billID,
          element.amount,
          element.date,
          element.date,
        ])  
      } else {
        sql = `UPDATE customer_order SET paper_id = ?, amount = ?, date = ?, created_at =? WHERE order_id = ? `
        await con.query(sql, [
          element.paperID,
          element.amount,
          element.date,
          element.date,
          element.orderID
        ])
      }
    });

    await con.commit()
  } catch (e){
    await con.rollback()
    console.log(e)
    throw 'Something wrong please contract admin';
  } finally {
    con.close()
  }
}


module.exports = {insertOrUpdate}