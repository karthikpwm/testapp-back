const {db} = require('./../config/config')

const insertOrUpdate = async (param) => {
  const con = await db.getConnection()

  try {
    await con.beginTransaction();
    let receiptID, sql;

    const receipt = param.receipt
    if(element.adjustmentID === undefined || parseInt(element.adjustmentID) === 0 ){
      sql = "INSERT INTO customer_receipt (receipt_no, customer_id, date, remarks, amount) VALUE (?, ?, ?, ?, ?)";
      const receiptResult = await con.query(sql,[
        receipt.receiptNo, receipt.customerID, receipt.date, receipt.remarks, receipt.amount
      ])
      receiptID = receiptResult[0].insertId
    } else {
      sql = "UPDATE customer_receipt SET date = ?, remarks = ?, amount = ? WHERE receipt_id = ?";
      await con.query(sql,[
        receipt.date, receipt.remarks, receipt.amount, receipt.receiptID
      ])
    }


    await param.credit.forEach(async element => {
      if(element.adjustmentID === undefined || parseInt(element.adjustmentID) === 0 ){
        sql = `INSERT INTO adjustment_credit ( receipt_id, bill_id, customer_id, amount )`
        await con.query(sql, [
          receiptID,
          element.billID,
          element.customerID,
          element.amount
        ])
      } else {
        sql = `UPDATE adjustment_credit SET amount = ? WHERE adjustment_id = ? `
        await con.query(sql, [
          element.amount,
          element.adjustmentID,
        ])
      }
    });

    await param.bill.forEach(async element => {
      sql = `UPDATE customer_bill SET balance = ? WHERE bill_id = ?`
      await con.query(sql, [
        element.balance,
        element.billID,
      ])  
    });

    await con.commit()
  } catch (e){
    await con.rollback()
    console.log(e)
    throw 'Something wrong please contract admin';
  } finally {
    con.close()
  }
}


module.exports = {insertOrUpdate}