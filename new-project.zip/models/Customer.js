const {db} = require('./../config/config')

const insert = async ( param ) => {
  const con = await db.getConnection()
  try {
    await con.beginTransaction();
    const result =  await con.query("INSERT INTO customer (name, mobile, place_id, created_at) VALUE ( ?, ?, ?, ? ) ", 
      [param.name, param.mobile, param.placeID, param.date ])
    await con.commit();
    return result;
  } catch ( err ) {
    await con.rollback();
    throw err;
  } finally {
    con.close()
  }
}

const update = async ( param ) => {
  const con = await db.getConnection()
  try {
    await con.beginTransaction();
    const result =  await con.query("UPDATE customer SET name = ?, mobile = ?, place_id = ? WHERE customer_id = ? ", 
      [param.name, param.mobile, param.placeID, param.date, param.customerID ])
    await con.commit();
    return result;
  } catch ( err ) {
    await con.rollback();
    throw err;
  } finally {
    con.close()
  }
}
module.exports = {insert, update}